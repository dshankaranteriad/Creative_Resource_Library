<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lead MarketWise</title>
  <!-- CSS only -->
	<link rel="icon" type="image/png" href="https://leadmarketwise.com/lmw/resources/favicon.png">
	
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<style>
   @import url('https://fonts.googleapis.com/css2?family=Noto+Sans&display=swap');
    body{
        background-color: #E8ECEE;
        font-family: 'Noto Sans', sans-serif;
    }
			table{
		width: 100%;
	}
	.table-responsive{
		display: contents;
	}
	.box {
  box-shadow:
  0 2.8px 2.2px rgba(0, 0, 0, 0.034),
  0 6.7px 5.3px rgba(0, 0, 0, 0.048),
  0 12.5px 10px rgba(0, 0, 0, 0.06),
  0 22.3px 17.9px rgba(0, 0, 0, 0.072),
  0 41.8px 33.4px rgba(0, 0, 0, 0.086),
  0 100px 80px rgba(0, 0, 0, 0.12);

		border-radius: 5px;
		margin-bottom: 10px;
}
	

    .border-style{
        border-top: 10px solid #00AA55; 
	
	border-bottom: 10px solid #00AA55;
		width: 750px;
    }
	h3{
		padding-top: 10px;
		font-size: 22px;
		color: #00AA55;
	}
	
	.btn-success1 {
    color: #FFFFFF;
    background-color:#00AA55;
    border-color: #00AA55;
	text-align: center;
		
}

.btn-success1:hover {
    color: #FFFFFF;
    background-color: #00AA55;
    border-color: #00AA55;
}

    </style>

<body>
<!--Body part Starts-->	
<div  class="container box border-style" style="background-color: #FFFFFF; margin-top: 10%;">
	<table>
	<tbody class="table table-borderless table-responsive">
		<tr scope="col">
		<td>
			  <h3 style="text-align: center;">Switch to our Weekly Email</h3>
			  <p style="font-size: 13px; text-align: center;">If the daily email is too much, switch to our weekly email instead.</p></td></tr><tr>
                 <td align="center" style ="border-bottom: 0.5px solid rgb(192,192,192);">
					 <button class="btn btn-success1" data-toggle="modal" data-target="#myModal" > Switch to weekly</button>
					 <div class="modal fade" id="myModal">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Thank you!</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
           Your preference is saved.
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
					 </td>
               </tr>
		<tr scope="col">
		<td>
			  <h3 style="text-align: center;">Still wish to UNSUBSCRIBE</h3>
			  <p style="font-size: 13px; text-align: center;">To confirm your request please click the button below.</td></tr><tr>
                 <td align="center" style="padding-left: 3%; padding-bottom: 3%;"><a href="https://leadmarketwise.com/lmw/resources/unsub-thankyou.php">
					 <button class="btn btn-success1"> UNSUBSCRIBE</button>
					</a></td>
               </tr>
		</tbody>
	</table></div>
	<!--Body part Ends here-->
</body>
</head>
</html>